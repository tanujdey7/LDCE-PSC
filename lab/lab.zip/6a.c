#include<stdio.h>
int main() {
    int x1 = 3; 
    int y1 = 7; 
    int x2 = 8; 
    int y2 = 12;
    float slope = (y2-y1)/(x2-x1);
    printf("%f",slope); 
}