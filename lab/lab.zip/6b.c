#include<stdio.h>
int main() {
    int x1 = 5;
    int y1 = 4;
    int x2 = 8;
    int y2 = 10;
    float coo1 = ((x1 + x2 ) / 2);
    float coo2 = ((y1 + y2 ) / 2);
    printf("%f\n",coo1);
    printf("%f",coo2);
}