#include <stdio.h>
int main() {
    int num1 = 10;
    int num2 = 2;
    printf("Quotient: %d\n",num1/num2);
    printf("Denominator: %d",num1%num2);
}