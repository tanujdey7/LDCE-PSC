#include<stdio.h>
int main() {
    printf("Hello World\n");
    printf("My Name is Tanuj Dey\n");
    printf("Ahmedabad, Gujarat");
}