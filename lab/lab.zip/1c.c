#include<stdio.h>
int main() {
    int a,b,c,d,e;
    printf("Enter 5 Number: ");
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    scanf("%d",&d);
    scanf("%d",&e);
    printf("%d",(a+b+c+d+e));
    float a1,b1,c1,d1,e1;
    printf("\nEnter 5 Number: ");
    scanf("%f",&a1);
    scanf("%f",&b1);
    scanf("%f",&c1);
    scanf("%f",&d1);
    scanf("%f",&e1);
    printf("%f",(a1+b1+c1+d1+e1));
}