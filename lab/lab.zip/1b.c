#include<stdio.h>
int main() {
    int x1 = 2;
    int x2 = 7;
    printf("x1 = %d x2 = %d",x1,x2);
}