#include<stdio.h>
#include<string.h>
int main() {
    char c[] = "Tanuj";
    strrev(c);
    printf("%s",c);
}